$(document).ready(function(){
    
//    $("p").click(function(){
//        $(this).hide();
//    });
//    
//    $(window).resize(function(){
//        console.log("ㅋ");
//    });
//    
//    $(document).scroll(function(){
//        console.log("스크롤됨");
//    });
//    
    $(".login").click(function(){
        var uid = $("#userid").val().length;
        var upw = $("#userpw").val().length;
        var chk = uid * upw;
        if(chk == 0){
            alert("아이디와 비밀번호를 입력하세요");
        }else{
            $("#userid").val("");
            $("#userpw").val("");
        }
    });
    
    //로그인버튼이 눌리면
        //아이디칸에 쓴 값이 몇글자인지
        //비번칸에 쓴 값이 몇글자인지 알아내서
        //그 두 수를 곱해서
        //만약 그 값이 0이라면
            //경고창 "아이디와 비밀번호를 입력하세요"
        //아니라면
            //창을 닫기
    
    function buzz(){
        var 
    }
    
});









